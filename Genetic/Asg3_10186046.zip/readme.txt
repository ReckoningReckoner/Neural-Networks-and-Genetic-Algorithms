CMPE452: Assignment 3
Viraj Bangari 10186045
March 20 2018

Running instructions:
Use python3 with numpy and scipy installed. Then, just run python3 pca.py.
Note: this will overrwrite the wav and csv that I generated before.


Initial weights, learning rate, final weights:
See Output/output.txt

Termination Criteria:
Keep iterating until the absolute difference of the norm of W with 1 is less than epsilon, or 10 iterations are reached.

Output:
Csv is is in Output/PCA.csv, wav is in Output/PCA.wav.
